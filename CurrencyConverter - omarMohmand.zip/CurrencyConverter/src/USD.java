// Omar Mohmand
// 2024-02-01
// Cosc 1200-03
// A currency converter that can convert to CAD, USD, EUR, GBP, and YEN
public class USD extends Currency {
    public USD() {
        super(1.35); // how much CAD its worth
    }

    @Override
    public double convertToCAD(double amount) {
        return amount * conversionRateToCAD;
    } //the math involved, if you want to convert, it first converts to cad
    // then it multiplies to the conversion rate of the other currency your converting to
    @Override //using the override method to override the method from the currency class
    public double convertFromCAD(double amount) {
        return amount/ conversionRateToCAD;
    }

}