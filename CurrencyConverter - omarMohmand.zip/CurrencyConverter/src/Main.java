// Omar Mohmand
// 2024-02-01
// Cosc 1200-03
// A currency converter that can convert to CAD, USD, EUR, GBP, and YEN
import java.util.Scanner; //imports a scanner

public class Main {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in); // makes a scanner


        System.out.println("What currency would you like to convert from:"); // a string that asks for an input
        System.out.println("1. USD");
        System.out.println("2. EUR");
        System.out.println("3. GBP");
        System.out.println("4. YEN");
        int from_choice = scanner.nextInt(); //scanner Takes the users input and puts it into a variable called from_choice
System.out.println ( "what currency would you like to convert to? (note this will also show you the amount in CAD) " ); // a string that asks for an input
        System.out.println("1. USD");
        System.out.println("2. EUR");
        System.out.println("3. GBP");
        System.out.println("4. YEN");
        int to_choice = scanner.nextInt(); //scanner Takes the users input and puts it into a variable called to_choice
System.out.println ( "How much do you want to convert? " );
double amount = scanner.nextDouble ();

        Currency fromCurrency = null; //intelliJ told me to add this
        Currency toCurrency = null; //intelliJ told me to add this

switch (from_choice) { // a list of currencies that the user can convert from (note that the variable from_choice will hold the value of which currency the user will pick and will print it at the end
    case 1:
        fromCurrency =new USD (); // uses a new instance of USD
        break;
    case 2:
        fromCurrency= new EUR ();// uses a new instance of EUR
        break;
    case 3:
        fromCurrency = new GBP ();// uses a new instance of GBP
        break;
    case 4:
        fromCurrency = new YEN ();// uses a new instance of YEN
        break;
    default:
        System.out.println ( "Error, you did not press 1,2,3, or 4" ); //a line that prints if you don't click one of the 4 choices
}
switch (to_choice) { // a list of currencies that the user can convert to (note that the variable to_choice will hold the value of which currency the user will pick and will print it at the end
    case 1:
        toCurrency =new USD ();
        break;
    case 2:
        toCurrency= new EUR ();
        break;
    case 3:
        toCurrency = new GBP ();
        break;
    case 4:
        toCurrency = new YEN ();
        break;
    default:
        System.out.println ( "Error, you did not press 1,2,3, or 4" ); //a line that prints if you don't click one of the 4 choices

}
        assert fromCurrency != null;// intellij told me to add it
        double convertedAmountToCAD = fromCurrency.convertToCAD(amount);  //this holds the value of CAD for the currency your converting to
        assert toCurrency != null;// intellij told me to add it
        double convertedAmountFromCAD = toCurrency.convertFromCAD (convertedAmountToCAD); //this holds the value of CAD for the currency your converting to
        // this portion of math is to get the currency name your converting to and what it is in CAD and round to 2 decimal places
System.out.println ( "The amount converted from " + fromCurrency.getClass ().getSimpleName () + " is this much in CAD: " + Math.round(convertedAmountToCAD * 100.0)/ 100.0);
System.out.println ( "the amount converted from "+ fromCurrency.getClass ().getSimpleName ()+  " to " + toCurrency.getClass ().getSimpleName () + " is " + Math.round(convertedAmountFromCAD * 100.0)/100.0);
        // this portion of math is to get the currency name your converting to and from and round to 2 decimal places
    }
}
