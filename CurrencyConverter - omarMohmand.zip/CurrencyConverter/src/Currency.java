// Omar Mohmand
// 2024-02-01
// Cosc 1200-03
// A currency converter that can convert to CAD, USD, EUR, GBP, and YEN
public abstract class Currency { // IntelliJ told me to make this its own class

    protected double conversionRateToCAD; // makes a variable to store the conversion rate to CAD

    public Currency(double conversionRateToCAD) { // Constructor for class
        this.conversionRateToCAD = conversionRateToCAD; // Initializes the conversion rate with the given value
    }

    public abstract double convertToCAD(double amount); // makes an abstract method to convert amount to CAD (to CAD)

    public abstract double convertFromCAD(double amount); // makes an abstract method to convert amount from CAD (from CAD)
}
